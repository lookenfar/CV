clc, clear all, close all;

labels=readtable("FETAL_PLANES_DB_data.csv");
planes=labels.Plane;

db=imageDatastore('Images');
db.Labels=categorical(planes);


%% filter data

db_new=subset(db, ismember(db.Labels, {'Fetal femur','Fetal brain','Maternal cervix'}));
db_new.Labels = removecats(db_new.Labels, setdiff(categories(db_new.Labels), {'Fetal femur','Fetal brain','Maternal cervix'}));

%% data augmentation
maternal_cervix_idx = find(db_new.Labels == categorical({'Maternal cervix'}));
maternal_cervix = subset(db_new, maternal_cervix_idx);
countEachLabel(maternal_cervix)

fetal_femour_idx = find(db_new.Labels == categorical({'Fetal femur'}));
fetal_femour = subset(db_new, fetal_femour_idx);
countEachLabel(fetal_femour)


augmenter = imageDataAugmenter(...
    'RandRotation', [-10, 10], ...
    'RandXTranslation', [-10, 10], ...
    'RandYTranslation', [-10, 10]);

maternal_cervix_aug = augmentedImageDatastore([227 227], maternal_cervix, 'DataAugmentation', augmenter);
fetal_femour_aug1 = augmentedImageDatastore([227 227], fetal_femour, 'DataAugmentation', augmenter);
fetal_femour_aug2 = augmentedImageDatastore([227 227], fetal_femour, 'DataAugmentation', augmenter);


label_maternal_cervix = repmat({'Maternal cervix'}, numel(maternal_cervix_aug.Files), 1);
maternal_cervix_aug_db=imageDatastore(maternal_cervix_aug.Files,'Labels',categorical(label_maternal_cervix));

label_fetal_femour = repmat({'Fetal femur'}, numel(fetal_femour.Files), 1);
fetal_femour_aug_db_1=imageDatastore(fetal_femour_aug1.Files,'Labels',categorical(label_fetal_femour));
fetal_femour_aug_db_2=imageDatastore(fetal_femour_aug2.Files,'Labels',categorical(label_fetal_femour));

aug_files=[db_new.Files;maternal_cervix_aug_db.Files;fetal_femour_aug_db_1.Files;fetal_femour_aug_db_2.Files];
aug_labels=[db_new.Labels;maternal_cervix_aug_db.Labels;fetal_femour_aug_db_1.Labels;fetal_femour_aug_db_2.Labels];

db_new=imageDatastore(aug_files,'Labels',aug_labels);
%-------------------------------------------------

disp('full data store')
tbl=countEachLabel(db_new)
min_set_count=min(tbl{:,2});

db_new=splitEachLabel(db_new,min_set_count,'randomized');

countEachLabel(db_new)


%% visualize

Fetal_femur=find(db_new.Labels=='Fetal femur',1);
Fetal_brain=find(db_new.Labels=='Fetal brain',1);
Maternal_cervix=find(db_new.Labels=='Maternal cervix',1);

figure
subplot(131)
imshow(readimage(db_new,Fetal_femur)),title('Fetal femur')
subplot(132)
imshow(readimage(db_new,Fetal_brain)),title('Fetal brain')
subplot(133)
imshow(readimage(db_new,Maternal_cervix)),title('Maternal cervix')


%% CNN to extract features

net=alexnet();

%% preprocess

db_new.ReadFcn=@(filename)readAndPreprocessImage(filename);

%% train test split
[training_set,test_set] = splitEachLabel(db_new,0.7, 'randomized' );

disp('train')
countEachLabel(training_set)
disp('test')
countEachLabel(test_set)

%% obtaining features from fc7 layer

featureLayer = 'fc7';
trainingFeatures = activations(net, training_set, featureLayer, ...
    'MiniBatchSize', 32, 'OutputAs', 'columns');

trainingLabels = training_set.Labels;

%% Train multiclass SVM classifier 
classifierSVM = fitcecoc(trainingFeatures, trainingLabels, ...
    'Learners', 'Linear', 'Coding', 'onevsall', 'ObservationsIn', 'columns');


%% test SVM classifier 

for i = 1:numel(test_set.Files)
    img = readAndPreprocessImage(test_set.Files{i});

    imageFeatures = activations(net, img, featureLayer);

    imageFeatures = reshape(imageFeatures,size(imageFeatures,2), size(imageFeatures,3));

    predicted_labels_SVM(i) = predict(classifierSVM, imageFeatures);
end

%% confusion matrix SVM classifier 

test_labels=test_set.Labels;

conf_mat_SVM=confusionmat(test_labels,predicted_labels_SVM);

conf_mat_SVM = bsxfun(@rdivide,conf_mat_SVM,sum(conf_mat_SVM,2))

mean_acc_SVM=mean(diag(conf_mat_SVM));


accouracy_SVM=zeros(size(conf_mat_SVM,1));

disp('accouracy with Support Vector Machines')
for i=1:size(conf_mat_SVM,1)
    TP=conf_mat_SVM(i,i);
    tot=sum(conf_mat_SVM(:,i));

    accouracy_SVM(i)=TP/tot;
    disp('accouracy for class '+string(i)+': '+string(accouracy_SVM(i)))
end
disp('Mean accouracy: '+string(mean_acc_SVM))

%% Train multiclass Tree classifier 
classifierTree = fitctree(trainingFeatures', trainingLabels);


%% test Tree classifier

for i = 1:numel(test_set.Files)
    img = readAndPreprocessImage(test_set.Files{i});

    imageFeatures = activations(net, img, featureLayer);

    imageFeatures = reshape(imageFeatures,size(imageFeatures,2), size(imageFeatures,3));

    predicted_labels_Tree(i) = predict(classifierTree, imageFeatures);
end

%% confusion matrix Tree classifier

test_labels=test_set.Labels;

conf_mat_tree=confusionmat(test_labels,predicted_labels_Tree);

conf_mat_tree = bsxfun(@rdivide,conf_mat_tree,sum(conf_mat_tree,2))

mean_acc_tree=mean(diag(conf_mat_tree));

accouracy_tree=zeros(size(conf_mat_tree,1));

disp('accouracy with Decision Tree')
for i=1:size(conf_mat_tree,1)
    TP=conf_mat_tree(i,i);
    tot=sum(conf_mat_tree(:,i));

    accouracy_tree(i)=TP/tot;
    disp('accouracy for class '+string(i)+': '+string(accouracy_tree(i)))
end
disp('Mean accouracy: '+string(mean_acc_tree))
