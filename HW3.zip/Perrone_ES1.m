clc, clear all, close all;

labels=readtable("FETAL_PLANES_DB_data.csv");
planes=labels.Plane;

db=imageDatastore('Images');
db.Labels=categorical(planes);


%% filter data

db_new=subset(db, ismember(db.Labels, {'Fetal femur','Fetal brain','Maternal cervix'}));
db_new.Labels = removecats(db_new.Labels, setdiff(categories(db_new.Labels), {'Fetal femur','Fetal brain','Maternal cervix'}));

countEachLabel(db_new)

%% data augmentation
maternal_cervix_idx = find(db_new.Labels == categorical({'Maternal cervix'}));
maternal_cervix = subset(db_new, maternal_cervix_idx);
countEachLabel(maternal_cervix)

fetal_femour_idx = find(db_new.Labels == categorical({'Fetal femur'}));
fetal_femour = subset(db_new, fetal_femour_idx);
countEachLabel(fetal_femour)


augmenter = imageDataAugmenter(...
    'RandRotation', [-10, 10], ...
    'RandXTranslation', [-10, 10], ...
    'RandYTranslation', [-10, 10]);

maternal_cervix_aug = augmentedImageDatastore([227 227], maternal_cervix, 'DataAugmentation', augmenter);
fetal_femour_aug1 = augmentedImageDatastore([227 227], fetal_femour, 'DataAugmentation', augmenter);
fetal_femour_aug2 = augmentedImageDatastore([227 227], fetal_femour, 'DataAugmentation', augmenter);


label_maternal_cervix = repmat({'Maternal cervix'}, numel(maternal_cervix_aug.Files), 1);
maternal_cervix_aug_db=imageDatastore(maternal_cervix_aug.Files,'Labels',categorical(label_maternal_cervix));

label_fetal_femour = repmat({'Fetal femur'}, numel(fetal_femour.Files), 1);
fetal_femour_aug_db_1=imageDatastore(fetal_femour_aug1.Files,'Labels',categorical(label_fetal_femour));
fetal_femour_aug_db_2=imageDatastore(fetal_femour_aug2.Files,'Labels',categorical(label_fetal_femour));

aug_files=[db_new.Files;maternal_cervix_aug_db.Files;fetal_femour_aug_db_1.Files;fetal_femour_aug_db_2.Files];
aug_labels=[db_new.Labels;maternal_cervix_aug_db.Labels;fetal_femour_aug_db_1.Labels;fetal_femour_aug_db_2.Labels];

db_new=imageDatastore(aug_files,'Labels',aug_labels);
%-------------------------------------------------


disp('full data store')
tbl=countEachLabel(db_new)
min_set_count=min(tbl{:,2});


db_new=splitEachLabel(db_new,min_set_count,'randomized');

countEachLabel(db_new)


%% visualize

Fetal_femur=find(db_new.Labels=='Fetal femur',1);
Fetal_brain=find(db_new.Labels=='Fetal brain',1);
Maternal_cervix=find(db_new.Labels=='Maternal cervix',1);

figure
subplot(131)
imshow(readimage(db_new,Fetal_femur)),title('Fetal femur')
subplot(132)
imshow(readimage(db_new,Fetal_brain)),title('Fetal brain')
subplot(133)
imshow(readimage(db_new,Maternal_cervix)),title('Maternal cervix')

%% preprocess

db_new.ReadFcn=@(filename)readAndPreprocessImage(filename);

%% train test split
[training_set,test_set] = splitEachLabel(db_new,0.7, 'randomized' );

disp('train')
countEachLabel(training_set)
disp('test')
countEachLabel(test_set)

%% HOG first image (to get feature size)
img=readAndPreprocessImage(db_new.Files{1});
img=im2gray(img);

[hog_4x4,vis_4x4]=extractHOGFeatures(img,'CellSize',[4 4]);
[hog_8x8,vis_8x8]=extractHOGFeatures(img,'CellSize',[8 8]);

hogFeatureSize4=size(hog_4x4,2);
hogFeatureSize8=size(hog_8x8,2);


%% HOG train

train_len=numel(training_set.Files);
train_features4=zeros(train_len,hogFeatureSize4);
train_features8=zeros(train_len,hogFeatureSize8);

for i=1:train_len
    
    img=readAndPreprocessImage(training_set.Files{i});

    [train_features4(i,:),vis_4x4]=extractHOGFeatures(img,'CellSize',[4 4]);
    [train_features8(i,:),vis_8x8]=extractHOGFeatures(img,'CellSize',[8 8]);

end

%% SVM

classifier4 = fitcecoc(train_features4, training_set.Labels);
classifier8 = fitcecoc(train_features8, training_set.Labels);

%% HOG on test

test_len=numel(test_set.Files);
test_features4=zeros(test_len,hogFeatureSize4);
test_features8=zeros(test_len,hogFeatureSize8);

for i=1:test_len

    img=readAndPreprocessImage(test_set.Files{i});
    
    [test_features4(i,:),vis_4x4]=extractHOGFeatures(img,'CellSize',[4 4]);
    [test_features8(i,:),vis_8x8]=extractHOGFeatures(img,'CellSize',[8 8]);


    predicted_labels4(i) = predict(classifier4, test_features4(i,:));
    predicted_labels8(i) = predict(classifier8, test_features8(i,:));
end

%% confusion matrix 4x4

test_labels=test_set.Labels;

conf_mat_4=confusionmat(test_labels,predicted_labels4);

conf_mat_4 = bsxfun(@rdivide,conf_mat_4,sum(conf_mat_4,2))

mean_acc_4=mean(diag(conf_mat_4));

accouracy4=zeros(size(conf_mat_4,1));


disp('accouracy with HOG Cellsize = [4x4]')
for i=1:size(conf_mat_4,1)
    TP=conf_mat_4(i,i);
    tot=sum(conf_mat_4(:,i));

    accouracy4(i)=TP/tot;
    disp('  accouracy for class '+string(i)+': '+string(accouracy4(i)))
end
disp('Mean accouracy: '+string(mean_acc_4))

%% confusion matrix 8x8

test_labels=test_set.Labels;

conf_mat_8=confusionmat(test_labels,predicted_labels8);

conf_mat_8 = bsxfun(@rdivide,conf_mat_8,sum(conf_mat_8,2))

mean_acc_8=mean(diag(conf_mat_8));
disp(mean_acc_8)


accouracy8=zeros(size(conf_mat_4,1));

disp('accouracy with HOG Cellsize = [8x8]')
for i=1:size(conf_mat_8,1)
    TP=conf_mat_8(i,i);
    tot=sum(conf_mat_8(:,i));

    accouracy8(i)=TP/tot;
    disp('  accouracy for class '+string(i)+': '+string(accouracy8(i)))
end
disp('Mean accouracy: '+string(mean_acc_8))
