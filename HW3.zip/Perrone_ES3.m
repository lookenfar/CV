clc,clear,close all;
load CMR_thorax.mat;

hei=size(vol,1);
wid=size(vol,2);
L=size(vol,3);

%% thorax

IcatT=zeros(hei,wid,L);

bkg=zeros(hei,wid,L);

for i=1:L
    a=vol(:,:,i);
    a=im2double(a);
    a=imadjust(a);
    %binarize
    thorax_bin=a>.1;
    %adjust mask
    thorax_bin=bwfill(thorax_bin,'holes');

    thorax_bin=imopen(thorax_bin,strel('disk',4));
    
    thorax_bin = bwareaopen(thorax_bin, 5000);
    %store the background
    bkg(:,:,i)=~thorax_bin;
    
    IcatT(:,:,i) = bwperim(thorax_bin);
end

%% lungs

IcatLUNG=zeros(hei,wid,L);

vol_lung_R=zeros(L,1);
vol_lung_L=zeros(L,1);

for i =1:L
    a=vol(:,:,i);
    a=im2double(a);
    a=imadjust(a);

    %binarize
    op=imopen(a,strel('disk',4));
    op_bin=op>.1;
    %adjust mask
    op_bin=imclose(op_bin,strel('disk',10));
    op_bin=imopen(op_bin,strel('disk',6));
    %remove background
    lungs_bin=op_bin+bkg(:,:,i);
    
    lungs_bin_neg=~lungs_bin;
    lungs_bin_neg=bwareaopen(lungs_bin_neg,2000);
    lungs_bin_neg=bwfill(lungs_bin_neg,'holes');

    %mirrored image check
    a_flip=fliplr(lungs_bin_neg);
    
    a_sum=a_flip+lungs_bin_neg;
    if any(a_sum(:) == 2)
        IcatLUNG(:,:,i) = bwperim(lungs_bin_neg);
    else
        lungs_bin_neg=zeros(hei,wid);
        IcatLUNG(:,:,i) = bwperim(lungs_bin_neg);
    
    end
    
    %lungs volume
    lungs_L=imtranslate(lungs_bin_neg,[wid/2 0]);
    vol_lung_L(i)=sum(sum(lungs_L>0));
    
    lungs_R=imtranslate(lungs_bin_neg,[-wid/2 0]);
    vol_lung_R(i)=sum(sum(lungs_R>0));


end

%% PLOT

for i=1:5:L
    a=vol(:,:,i);

    [x_tor,y_tor]=find( IcatT(:,:,i)==1);
    [x_lung,y_lung]=find(IcatLUNG(:,:,i)==1);

    disp('Slice '+string(i))
    disp('Left Lung volume (in pixels)')
    disp(vol_lung_L(i))
    disp('Right Lung volume (in pixels)')
    disp(vol_lung_R(i))

    figure
    imshow(a,[])
    hold on
    plot(y_tor,x_tor,'.yellow')
    plot(y_lung,x_lung,'.magenta')
    hold off

    waitforbuttonpress
end

tot_vol_L=sum(vol_lung_L(:));
tot_vol_R=sum(vol_lung_R(:));

disp('Total Left Lung volume (in pixels)')
disp(tot_vol_L)
disp('Total Right Lung volume (in pixels)')
disp(tot_vol_R)

%% thorax vol plot

volshow(IcatT,'Colormap', 'yellow');


%% lungs vol plot

volshow(IcatLUNG,'Colormap', 'magenta');

