clc,clear,close all;
%% INPUT
load("loopMRI.mat");
L=size(slice6,4);

%% FRAME
frame=cell(L,1);

figure
for i=1:L
    frame{i}=slice6(:,:,i);
    frame{i}=histeq(frame{i});
    frame{i}=im2double(frame{i});

    subplot(5,5,i)
    imshow(frame{i}),title(string(i));    
end
%% GET COORDINATES

figure
disp('Please select in the image one pixel within LV endocardium area, then press enter');
[x0,y0,p0]=impixel(frame{1},[]);
clc;

%% BOUNDARIES

b=cell(L,1);
eccentricity=zeros(1, 25);

for i=1:L
    bw=k_means_fun(frame{i},x0,y0);
    bw = bwselect(bw,y0,x0);
    bw=bwfill(bw,'holes');

    % slice volume in ml
    area=sum(bw(:) == 1);
    area_mm=area* 1/(xres*yres*zres);
    area_ml=area_mm/1000;

    disp('area LV in frame '+ string(i) + ': ' + string(area_mm) + ' mm^3, or: '+ string(area_ml) + ' ml');

    % eccentricity
    stats = regionprops(bw, 'Eccentricity');
    eccentricity(i) = [stats.Eccentricity];

    % boundaries
    [b{i},l,nr,a]=bwboundaries(bw,8,'holes');
    b{i}{1,1}=flip(b{i}{1,1});

    %plot
    figure
    imshow(frame{i}),title('frame '+string(i));
    hold on
    plot(b{i}{1,1}(:,2),b{i}{1,1}(:,1), '.r');

    waitforbuttonpress
end

figure
plot(1:L, eccentricity, '-o'),title('Eccentricity plot')
xlabel('Frame');
ylabel('Eccentricity');

%% SAVE BOUNDARIES COORDINATES
save('countours','b');


%%
x=b{1}{1,1}(:,1);
y=b{1}{1,1}(:,2);
M=size(x,1);


figure
imshow(frame{1});
hold on
for i=1:M
    plot(y(i),x(i),'.r')
    hold on
    waitforbuttonpress;
end

%% kmeans func

function bw=k_means_fun(ac,x0,y0)

    N = size(ac, 1);
    M = size(ac, 2);

    [cluster_idx, ~] = kmeans(ac(:), 5, 'distance', 'sqEuclidean', 'Replicates', 3);
    pixel_labels = reshape(cluster_idx, N, M);

    bw=zeros(N,M,'double');

    [p]=impixel(pixel_labels,x0,y0);

    for i=1:N
        for j=1:M
            if pixel_labels(i,j)==p(1)
                bw(i,j)=1;
            end
        end
    end
end














